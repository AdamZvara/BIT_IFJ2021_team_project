/**
 * VUT IFJ Project 2021.
 *
 * @file main.c
 *
 * @brief Source file which starts compiler
 *
 * @author Vojtěch Eichler
 * @author Václav Korvas
 * @author Tomáš Matuš
 * @author Adam Zvara
 */

#include "parser.h"

int main() {
	return parse();
}
